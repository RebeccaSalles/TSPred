#Updating parameters
updt <- function(obj,...){
  UseMethod("updt")
}

#COPY
#objs <- function(obj,...){
#  UseMethod("objs")
#}

#COPY
#res <- function(obj,...){
#  UseMethod("res")
#}

#COPY
#subset <- function(obj,...){
#  UseMethod("subset")
#}

#COPY
#preprocess <- function(obj,...){
#  UseMethod("preprocess")
#}

#COPY
#train <- function(obj,...){
#  UseMethod("train")
#}

#predict is already a generic method
#predict <- function(obj,...){
#  UseMethod("predict")
#}

#COPY
#postprocess <- function(obj,...){
#  UseMethod("postprocess")
#}

#COPY
#evaluate <- function(obj,...){
#  UseMethod("evaluate")
#}

#COPY
#workflow <- function(obj,...){
#  UseMethod("workflow")
#}

#COPY
#benchmark <- function(obj,...){
#  UseMethod("benchmark")
#}